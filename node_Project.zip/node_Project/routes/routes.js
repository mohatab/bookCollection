const express = require("express");
const router = express.Router();
const User = require("../models/users");
const multer = require("multer");

//insert user to database
router.post("/add", (req, res) => {
  const user = new User({
    name: req.body.name,
    email: req.body.email,
    book: req.body.book,
    genre: req.body.genre,
    author: req.body.author,
  });
  newUser
    .save()
    .then(() => res.status(200).send("User saved successfully"))
    .catch((error) =>
      res.status(500).send("Error saving user: " + error.message)
    );
  user.save((error) => {
    if (err) {
      res.json({ message: err.message, type: "danger" });
    } else {
      req.session.message = {
        type: "success",
        message: "User Added Successfully",
      };
      res.redirect("/");
    }
  });
});

router.get("/", (req, res) => {
  res.render("index", { title: "Home Page" });
});

router.get("/add", (req, res) => {
  res.render("add_users", { title: "Add Users" });
});
module.exports = router;
